<?php
    $db_base = 't953727y_ek'; // Имя БД
    $db_user = "t953727y_ek"; // Логин БД
    $db_password = "111111EKz"; // Пароль БД
	$db_host = "localhost"; 
    $db_table = "dannye"; // Имя Таблицы БД
?>